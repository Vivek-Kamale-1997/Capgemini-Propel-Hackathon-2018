alter table buses
drop column Ac_Available;