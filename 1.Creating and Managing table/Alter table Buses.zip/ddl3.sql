alter table buses
add Ac_Available varchar2(10);