CREATE table buses
(
Bus_no Number(11) CONSTRAINT PK_BUSES primary key,
Bus_name Varchar2(20),
type Varchar2(20),
Total_seats Number(11),
Avail_seats Number(11)
);