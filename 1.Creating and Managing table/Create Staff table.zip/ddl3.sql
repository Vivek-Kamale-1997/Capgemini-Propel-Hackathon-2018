CREATE table staff
( 
staff_id number primary key,
staff_name varchar2(30),
department_id number references department(department_id)
);