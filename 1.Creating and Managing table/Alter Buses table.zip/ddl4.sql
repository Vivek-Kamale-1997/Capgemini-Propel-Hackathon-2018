alter table buses
modify Ac_Available varchar(5);