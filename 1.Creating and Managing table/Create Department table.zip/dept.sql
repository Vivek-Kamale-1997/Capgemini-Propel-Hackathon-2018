CREATE table Department
(
department_id number primary key,
department_name varchar(30),
department_block_number number
);