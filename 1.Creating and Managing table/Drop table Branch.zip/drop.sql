drop table branch cascade constraints;
-- DROP TABLE BRANCH CASCADE bid varchar(6);