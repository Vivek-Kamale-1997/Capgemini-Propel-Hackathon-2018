drop table regions cascade constraints;
-- drop table regions PURGE;