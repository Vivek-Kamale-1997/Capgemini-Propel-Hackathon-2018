CREATE table jobs
(
job_id varchar2(10) primary key,
job_title varchar2(35) not null,
min_salary number(6) null,
max_salary number(6) null
);