create table SCHEDULE
(
Schedule_id Varchar2(3) CONSTRAINT PK_SCHEDULE primary key,
Travel_date Date,
Source Varchar2(20),
Destination Varchar2(20),
Bus_no Number(11) CONSTRAINT FK_SCHEDULE_BUSES  references Buses(bus_no),
Duration number(11)
);