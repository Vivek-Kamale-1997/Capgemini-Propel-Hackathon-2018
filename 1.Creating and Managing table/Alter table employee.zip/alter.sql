alter table employees
modify first_name varchar2(20) not null;