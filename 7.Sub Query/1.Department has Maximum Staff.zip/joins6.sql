select department_name 
from department natural join staff
group by department_id, department_name
having count(staff_id)=(select max(count(staff_id)) 
from staff
group by department_id);