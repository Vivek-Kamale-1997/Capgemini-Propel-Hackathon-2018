select s.staff_name
from staff s
inner join department d 
on d.department_id=s.department_id
where d.department_id in (select department_id from department where department_name='IT')
order by s.staff_name
;
