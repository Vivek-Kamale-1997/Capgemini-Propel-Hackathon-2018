select distinct subject_name,student_name from subject,student,mark
where student.student_id=mark.student_id and
subject.subject_id=mark.subject_id
and value=(select max(value) from mark where mark.subject_id=subject.subject_id group by subject_id)
group by student_name,subject_name
order by subject_name;