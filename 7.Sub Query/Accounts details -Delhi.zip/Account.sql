select a.acnumber,a.aod,a.opening_balance
from account a 
inner join branch b 
on a.bid=b.bid 
where b.bcity in (select bcity from branch where bcity='Delhi')
order by a.acnumber
;


-- select bcity from branch where bcity='Delhi';