select distinct(c.fname),a.acnumber,c.mobileno
from customer c
inner join account a
on c.custid=a.custid
inner join branch b
on b.bid=a.bid
where b.bcity in (select bcity from branch where bcity='Delhi')
order by c.fname,a.acnumber
;



-- select city from customer where city='Delhi';

-- select bcity from branch where bcity='Delhi';s