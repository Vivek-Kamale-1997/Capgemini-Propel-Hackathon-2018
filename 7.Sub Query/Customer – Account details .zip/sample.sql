select distinct(c.custid),a.acnumber,a.atype from customer c 
inner join account a 
on c.custid=a.custid
inner join trandetails t
on a.acnumber=t.acnumber
where t.transaction_amount in (select transaction_amount from trandetails where transaction_amount<5000)
order by custid;


-- select acnumber,transaction_amount from trandetails where transaction_amount<5000;

-- select atype from account;