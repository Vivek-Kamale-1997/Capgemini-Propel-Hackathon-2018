 select student.student_name,department.department_name,mark.value 
from student left join department on student.department_id=department.department_id
left join mark on student.student_id=mark.student_id
left join subject on subject.subject_id=mark.subject_id
where subject.subject_name='Software Engineering'
and value=(select max(value) from mark where mark.subject_id=subject.subject_id)
order by department_name,mark.value desc ;