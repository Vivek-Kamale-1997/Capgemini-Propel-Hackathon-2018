select distinct department_block_number from department
where department_block_number in(select max(department_block_number) from department);