select staff_name from staff,subject
where staff.staff_id=subject.staff_id
having count(subject_id)>1 group by staff_name order by staff_name asc;