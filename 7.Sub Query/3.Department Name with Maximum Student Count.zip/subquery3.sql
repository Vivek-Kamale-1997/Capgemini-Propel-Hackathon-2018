select department_name from department,student
where student.department_id=department.department_id
group by department_name having count(*)=(select max(count(*)) from  student group by department_id);