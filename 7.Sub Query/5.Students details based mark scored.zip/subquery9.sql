select student_name 
from Student 
where not exists (select * from Mark where student_id=student.student_id and 
value <=50)
order by student_name asc;
