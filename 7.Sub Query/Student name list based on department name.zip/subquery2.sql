select student_name from student 
where department_id in
(
select department_id from department where department_name='CSE'
) 
order by student_name desc
;