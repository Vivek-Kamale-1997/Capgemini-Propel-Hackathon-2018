select distinct u.name,u.address from users u,bookingdetails b
where b.user_id=u.user_id
and u.name not in(select distinct u.name
            from users u,bookingdetails b
            where b.user_id=u.user_id
            and upper(b.name) in ('HDFC'))
order by 1;
