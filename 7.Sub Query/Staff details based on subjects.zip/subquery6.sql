-- select staff_id,staff_name from staff
-- order by staff_id,staff_name asc;

select staff_name from staff where staff_id in
(
select staff_id from subject
GROUP BY staff_id
)
order by staff_name asc
;



--WORKING LOGIC
-- select distinct(st.staff_name) 
-- from staff st 
-- inner join subject su 
-- on st.staff_id=su.staff_id 
-- order by st.staff_name
-- ;

-- answer(handling/teaching one or more subjects)
-- Kartik
-- Lakshmi
-- Nisha
-- Venky
-- Viji