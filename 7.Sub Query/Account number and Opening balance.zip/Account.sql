select a.acnumber,a.opening_balance 
from account a 
inner join trandetails  t 
on a.acnumber=t.acnumber 
where t.medium_of_transaction in (select medium_of_transaction from trandetails where medium_of_transaction='Cheque')
order by a.acnumber,a.opening_balance
;

-- select medium_of_transaction from trandetails where medium_of_transaction='Cheque'; 