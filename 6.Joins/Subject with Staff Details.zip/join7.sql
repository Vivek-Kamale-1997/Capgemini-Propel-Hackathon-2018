select s.subject_name,s.subject_code,a.staff_name
from subject s
inner join staff a
on s.staff_id=a.staff_id
order by subject_code asc
;