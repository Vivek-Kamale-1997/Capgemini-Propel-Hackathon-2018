select distinct(c.fname),t.acnumber,t.tnumber,t.transaction_amount
from customer c
inner join account a
on a.custid=c.custid
inner join trandetails t
on a.acnumber=t.acnumber
where t.medium_of_transaction='Cash' and transaction_type='Deposit'
order by c.fname,t.acnumber,t.tnumber
;


-- select tnumber,acnumber,medium_of_transaction  from trandetails
-- where  medium_of_transaction='Cash'
-- ;

-- select * from trandetails;