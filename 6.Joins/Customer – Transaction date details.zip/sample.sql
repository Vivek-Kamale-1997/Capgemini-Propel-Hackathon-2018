select c.fname,a.acnumber,b.bname,t.dot
from customer c
inner join account a
on a.custid=c.custid
inner join branch b
on a.bid=b.bid
inner join trandetails t
on a.acnumber=t.acnumber
order by c.fname,a.acnumber,b.bname,t.dot
;