select s.student_name 
from student s
inner join department d
on s.department_id=d.department_id
where s.student_name like '%a' and d.department_name='IT'
order by s.student_name desc
;