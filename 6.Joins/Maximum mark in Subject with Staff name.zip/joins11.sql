select s.staff_name,s1.subject_name,max(m.value) as max_mark
from staff s
inner join subject s1
on s.staff_id=s1.staff_id
inner join mark m
on s1.subject_id=m.subject_id
group by s.staff_name,s1.subject_name
order by max_mark desc;