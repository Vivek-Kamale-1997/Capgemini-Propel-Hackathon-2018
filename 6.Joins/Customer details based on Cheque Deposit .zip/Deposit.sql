select distinct(c.fname),a.acnumber
from customer c
inner join account a
on a.custid=c.custid 
inner join trandetails t
on a.acnumber=t.acnumber 
where t.medium_of_transaction='Cheque' and transaction_type='Deposit'
order by c.fname,a.acnumber
;



-- select * from customer;
-- select * from account;
-- select * from trandetails where medium_of_transaction='Cheque';