select student_name, department_name
from student s join department d
on s.department_id = d.department_id
where city='Coimbatore' order by 1;