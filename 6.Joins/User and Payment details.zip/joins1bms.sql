select 
u.user_id as User_ID,
u.name as user_name,
t.ticket_id as Ticket_id,
(t.fare * t.no_seats) as Total_amount,
(t.fare * t.no_seats - d.discount_amount) as Paid_amount
from users u
inner join tickets t
on t.user_id=u.user_id
inner join payments p
on t.ticket_id=p.ticket_id
inner join discounts d
on p.discount_id=d.discount_id
order by u.user_id desc
;