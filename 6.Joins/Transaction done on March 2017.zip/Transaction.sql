select distinct(c.fname),a.acnumber
from customer c
inner join account a
on a.custid=c.custid
inner join trandetails t
on a.acnumber=t.acnumber
where t.dot like '%-MAR-17'
order by c.fname,a.acnumber
;

-- select dot from trandetails;