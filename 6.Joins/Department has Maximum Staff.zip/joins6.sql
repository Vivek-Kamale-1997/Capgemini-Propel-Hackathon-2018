-- select distinct(d.department_name)
-- from department d
-- inner join staff s
-- on d.department_id=s.department_id
-- where s.department_id=3
-- order by department_name desc;

-- select * from department;

-- select count(staff_id),department_id from staff
-- group by department_id;

select department_name  from department 
natural join staff
group by department_id,department_name
having count(staff_id)=(select max(count(staff_id)) from staff
group by department_id)
;