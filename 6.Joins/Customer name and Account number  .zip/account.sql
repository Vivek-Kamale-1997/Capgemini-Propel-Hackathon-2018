select fname , acnumber 
from customer c join account a
on c.custid=a.custid
order  by fname,acnumber;