select s.student_name,max(m.value) as max_mark
from student s
inner join mark m
on s.student_id=m.student_id
group by s.student_name
order by student_name;