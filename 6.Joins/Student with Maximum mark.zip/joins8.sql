select s.subject_name,min(m.value) as min_mark 
from  subject s 
inner join mark m
on s.subject_id=m.subject_id
group by subject_name
order by subject_name desc;

-- select min(value) as VL from mark
-- group by subject_id
-- order by VL desc
-- ;