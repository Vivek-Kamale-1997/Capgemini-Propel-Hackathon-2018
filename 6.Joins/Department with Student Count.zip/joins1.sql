-- select department_id,department_name from department;

-- select student_id,department_id from student;

select d.department_name,count(s.student_id) as student_count
from department d
inner join student s
on s.department_id=d.department_id
group by department_name
order by department_name;