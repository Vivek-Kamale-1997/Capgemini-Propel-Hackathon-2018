select u.user_id,u.name 
from users u
inner join tickets t
on t.user_id=u.user_id
inner join cancellation c
on c.ticket_id=t.ticket_id
order by user_id asc
;



-- select * from tickets;
-- select * from cancellation;