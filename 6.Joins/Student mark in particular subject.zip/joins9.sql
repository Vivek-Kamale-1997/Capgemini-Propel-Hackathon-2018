select s.student_name,m.value
from student s
inner join mark m
on s.student_id=m.student_id
where subject_id=4
order by  s.student_name
;

-- select subject_id,subject_name from subject;  --4