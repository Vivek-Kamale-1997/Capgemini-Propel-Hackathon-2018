select student_id,address from student where lower(student_name)='david';
