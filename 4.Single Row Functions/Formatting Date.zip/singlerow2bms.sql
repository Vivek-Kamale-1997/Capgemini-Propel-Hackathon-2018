select schedule_id,to_char(travel_date,'YYYY-MM-DD') as FormattedDate from schedule
order by schedule_id asc
;

--to_char(to_date(travel_date,'DD-MM-YY'),'YYYY-MM-DD')

-- select schedule_id,travel_date as FormattedDate from schedule
-- order by FormattedDate) desc;




-- select schedule_id,str_to_date(travel_date,'%yy%mm%dd') as FormattedDate from schedule
-- order by schedule_id asc
-- ;

-- select schedule_id,convert('travel_date',23)  as FormattedDate from schedule 
-- order by schedule_id asc
-- ;