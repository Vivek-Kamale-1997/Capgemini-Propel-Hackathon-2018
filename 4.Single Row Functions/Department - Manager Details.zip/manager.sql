-- select department_id,department_name,nvl2(manager_id,'manager_id','NA') manager_id from departments 
-- order by department_id
-- ;

select department_id,department_name,NVL(to_char(manager_id),'NA') MANAGER_ID
from departments 
order by department_id
;