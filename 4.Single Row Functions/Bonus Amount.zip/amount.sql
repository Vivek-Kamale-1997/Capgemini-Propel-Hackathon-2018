-- select employee_id,last_name,commission_pct as BONUS_AMT from employees
-- if(commission_pct>0 and commission_pct<0.2,salary * 0.10)
-- order by employee_id asc;

-- select employee_id,commission_pct as BONUS_AMT,
-- CASE
-- WHEN commission_pct>0 THEN salary*0.10
-- -- else "0"
-- END
-- FROM employees;

select employee_id,last_name, 
(
case 
when commission_pct>0 and commission_pct<0.2 then salary*0.10
when commission_pct>=0.2 then salary*0.15
else 0 
end
)
"BONUS_AMT"  from employees order by employee_id;