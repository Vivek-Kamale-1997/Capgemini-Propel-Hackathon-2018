select employee_id,start_date,end_date from job_history
where start_date like '%JAN%' and end_date like '%DEC%'
order by employee_id;

-- select start_date,end_date from job_history;