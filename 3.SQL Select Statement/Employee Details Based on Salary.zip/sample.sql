select employee_id,salary,hire_date from employees 
where salary between 8500 and 10000 
order by employee_id desc;