create view user_travel_details as
select u.user_id as user_id,u.name as user_name,s.source,s.destination
from users u
inner join tickets t 
on t.user_id=u.user_id
inner join schedule s
on s.schedule_id=t.schedule_id;

-- select * from user_travel_details;