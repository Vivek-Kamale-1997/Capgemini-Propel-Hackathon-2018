cal -B1 -A1 -m12 2015
# date 12252015
# cal -B1 -A1

# -y cal 11 2015  cal 12 2015
# cal 1 2016


