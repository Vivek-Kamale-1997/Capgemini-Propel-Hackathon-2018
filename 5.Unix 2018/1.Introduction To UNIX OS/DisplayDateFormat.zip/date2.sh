date +"DATE: %d/%m/%y"

# date --help