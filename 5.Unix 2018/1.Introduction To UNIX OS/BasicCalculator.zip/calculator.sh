# echo "2+5" | bc
# echo "5-2" | bc
# echo "4*2" | bc
# echo "4/2" | bc

bc
