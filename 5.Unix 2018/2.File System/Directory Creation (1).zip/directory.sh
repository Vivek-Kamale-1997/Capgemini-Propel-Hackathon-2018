mkdir livingthings
cd livingthings/
mkdir birds
mkdir plants
mkdir animals

cd animals/
mkdir mammals
cd mammals/
touch jaguar dog tiger

cd ..    #now :animals
mkdir reptiles
cd reptiles/
touch alligator skink turtle
cd ..  #now :animals
cd ..  #now :livingthings       #**DONE WITH ANIMALS**


cd plants/ 
touch carrot cabbage daisy      #**DONE WITH PLANTS**

cd .. #now :livingthings 

cd birds/
mkdir flyingbirds
mkdir nonflyingbirds

cd flyingbirds/
touch stork eagle eider

cd .. #now: birds
cd nonflyingbirds/
touch kiwi ostrich penguin   #**DONE WITH BIRDS**
