mkdir mydir
cd mydir/

mkdir colors
cd colors/
mkdir basic
cd basic/
touch red blue green
cd ..

mkdir blended
cd blended/
touch yellow orange pink
cd ..

cd ..
mkdir shape
cd shape/
touch circle square cube
cd ..

mkdir animals
cd animals/
mkdir mammals
cd mammals/
touch platypus bat dog
cd ..

mkdir reptiles
cd reptiles/
touch snakes crocodile lizard
cd ..
cd ..
cd ..





