# mv --help

mv mydir/animals/mammals/dog -tmydir/shape