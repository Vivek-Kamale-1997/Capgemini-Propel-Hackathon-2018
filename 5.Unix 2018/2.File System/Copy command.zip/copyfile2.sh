# pwd
cp livingthings/birds/flyingbirds/eider livingthings/animals/mammals