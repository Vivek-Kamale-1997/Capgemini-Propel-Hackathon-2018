cp  mydir/colors/basic/red mydir/colors/blended/

# cp -f  mydir/colors/basic/red mydir/colors/blended/ this forces copy

# cd mydir/colors/basic/
# cp red mydir/colors/blended