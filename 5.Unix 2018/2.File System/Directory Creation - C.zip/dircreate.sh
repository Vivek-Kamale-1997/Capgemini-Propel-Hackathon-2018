mkdir livingthings
cd  livingthings/
mkdir birds
mkdir plants
mkdir animals

cd animals/
mkdir mammals
cd mammals/
touch jaguar dog tiger

cd .. 
mkdir reptiles
cd reptiles/
touch alligator skink turtle
cd ..
cd ..


cd plants/
touch carrot cabbage daisy

cd ..

cd birds/
mkdir flyingbirds
mkdir nonflyingbirds

cd flyingbirds/
touch stork eagle eider

cd ..
cd nonflyingbirds/
touch kiwi ostrich penguin