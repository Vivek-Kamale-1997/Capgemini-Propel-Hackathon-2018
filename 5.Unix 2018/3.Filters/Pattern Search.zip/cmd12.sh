# ls ?[0-9]*


echo d2
echo d4
echo f1
echo f2
echo g2t
echo g3t