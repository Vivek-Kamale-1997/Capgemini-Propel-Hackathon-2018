grep '#' teknoscript.txt
