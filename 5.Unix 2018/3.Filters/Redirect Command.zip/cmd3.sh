grep -i "Birbal" sample.txt > redirlines.txt
# > redirlines.txt