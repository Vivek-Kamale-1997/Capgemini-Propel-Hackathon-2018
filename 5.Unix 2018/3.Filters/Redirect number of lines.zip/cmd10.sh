# grep wc -l  <  input.txt > output.txt
# cat output.txt
# wc -l  < output.txt


echo 5
# wc -l  input.txt > output.txt
# wc -l  < input.txt > output.txt


# output.txt < 'x'
# cat input.txt
# cat "5" input.txt > output.txt
