# echo 30 is Biggest number
# read a
# read b
# read c
if [$# -lt 2]
then
  echo "command line arguments are missing"
  elif [$1 -eq $2] && [$2 -eq $3]
  then
  echo "All the three numbers are equal"
  elif [$1 -eq $2] || [$1 -eq $c]
  then
  echo "I cannot figure out which number is biggest"
  elif [$1 -gt $2]
  then
  if [$1 -gt $3]
  then
  echo "$1 is Biggest number"
  else
  echo "$3 is Biggest number"
  fi
  elif [$2 -gt $3]
  then
  echo "$2 is Biggest number"
  else
  echo "$3 is Biggest number"
  fi