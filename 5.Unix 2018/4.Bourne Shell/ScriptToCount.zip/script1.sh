# w='cat test.txt | wc -w'
# echo 'Number of characters in test.txt is' | wc -m test.txt
# a='wc -w'
# read n
# echo Number of characters in test.txt is 20
# echo Number of words in test.txt is 3
# echo Number of lines in test.txt is 3
# # wc -w test.txt
# wc -l test.txt

c=`cat $1| wc -c`
w=`cat $1| wc -w`
l=`cat $1| wc -l`
echo "Number of characters in $1 is $c"
echo "Number of words in $1 is $w"
echo "Number of lines in $1 is $l"
