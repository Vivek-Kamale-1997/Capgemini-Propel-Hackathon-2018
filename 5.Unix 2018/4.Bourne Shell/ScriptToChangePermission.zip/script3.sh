# # file=  ~/test.txt
# # ls -l ~/test.txt  #to check permissions on any file

# if [ -e $file ]
# then  echo File Exists!

# elif [ ! -e $file ]
# then  echo File does not Exist

# fi 


# if [ ! -r  "$file" ]
# then  echo "File Permission has been changed";

# elif [ -w  "$file" ]
# then  echo "File Permission has been changed";

# fi
# # then
# #  sudo chmod u+w "$file" && echo "File is now readable"
# #  else echo File Permission has been changed

if [ ! -e $1 ]
then  
echo "File does not Exist"
else
echo "File Exists!"
if [ -w $1 ]
then
{ chmod go+w $1; }
fi
if [ -r $1 ]
then
{ chmod go+r $1; }
 fi
if [ ! -x $1 ]
then
{ chmod ugo+x $1; }
fi
echo "File Permission has been changed"
fi







