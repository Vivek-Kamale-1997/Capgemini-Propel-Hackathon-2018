update regions 
set region_name='Southeast Asia' where region_name='Asia';