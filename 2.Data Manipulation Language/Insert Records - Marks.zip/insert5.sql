insert into mark values('98',1,1);
insert into mark values('88',2,1);
insert into mark values('78',3,1);