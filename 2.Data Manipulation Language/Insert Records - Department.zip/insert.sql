insert into department values(1,'CSE',3);
insert into department values(2,'IT',3);
insert into department values(3,'SE',3);