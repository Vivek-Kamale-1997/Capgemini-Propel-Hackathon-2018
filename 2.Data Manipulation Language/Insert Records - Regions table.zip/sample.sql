insert into regions values(1,'Europe');
insert into regions values(2,'Americas');
insert into regions values(3,'Asia');