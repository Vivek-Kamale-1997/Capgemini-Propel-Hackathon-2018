insert into tickets values('T1','S5',null,1,2);
insert into tickets values('T2','S2',null,5,1);