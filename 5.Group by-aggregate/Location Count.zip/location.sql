SELECT city,count(location_id) as LOCATION_COUNT from locations
group by city
having count(location_id)>1
order by city
;

-- SELECT city,count(location_id) as LOCATION_COUNT from locations 
-- group by location_id
-- where location_id>1
-- order by city;