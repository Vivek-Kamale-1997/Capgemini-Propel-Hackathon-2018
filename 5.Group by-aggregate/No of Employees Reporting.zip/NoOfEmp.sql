select manager_id,count(employee_id) as NUMBER_OF_EMP from employees
group by manager_id
order by manager_id;

