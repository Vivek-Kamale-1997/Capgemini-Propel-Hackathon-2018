SELECT department_id,min(salary) as MIN_SALARY,max(salary) as MAX_SALARY FROM employees
GROUP BY department_id
ORDER BY department_id;