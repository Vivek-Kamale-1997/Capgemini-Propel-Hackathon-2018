-- SELECT student_id,min(value) as minimum_mark from mark
-- group by subject_id
-- ;

SELECT student_id,min(value) as minimum_mark from mark
group by student_id
order by minimum_mark asc;