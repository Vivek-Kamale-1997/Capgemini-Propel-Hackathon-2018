select student_id,round( (avg(value)) ,2) as  avg_mark from mark
group by student_id
having round( (avg(value)) ,2)>80
order by avg_mark
;