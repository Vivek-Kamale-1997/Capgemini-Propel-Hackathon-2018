-- select avg(value) as avg_mark from mark;

select round(max(avg(value)),2) as avg_mark from mark
group by student_id;